 If you use these codes, please cite the following paper, i.e., 
 
@article{FAN2022108509,
title = {Genetic programming for feature extraction and construction in image classification},
journal = {Applied Soft Computing},
volume = {118},
pages = {108509},
year = {2022},
issn = {1568-4946},
doi = {https://doi.org/10.1016/j.asoc.2022.108509},
url = {https://www.sciencedirect.com/science/article/pii/S1568494622000527},
author = {Qinglan Fan and Ying Bi and Bing Xue and Mengjie Zhang},
keywords = {Genetic programming, Image classification, Representation, Feature extraction, Feature construction},
abstract = {Genetic Programming (GP) has been successfully applied to image classification and achieved promising results. However, most existing methods either address binary image classification tasks only or need a predefined classifier to perform multi-class image classification while using GP for feature extraction. This limits their flexibility since it is unknown which combinations of classifiers and features are the most effective for an image classification task. Furthermore, high image variations increase the difficulty of feature extraction and image classification. This paper proposes a GP approach with a new program representation, new functions, and new terminals. The new approach can conduct feature extraction, feature construction, and classification, automatically and simultaneously. It can extract and construct informative image features, select a suitable classification algorithm instead of relying on a predefined classifier, and perform classification for binary and multi-class image classification tasks. In addition, this paper develops a new mutation operator based on fitness of population for dynamically adjusting the size of the evolved GP programs. The experimental results on eight datasets with different variations and difficulties show that the proposed approach achieves higher classification accuracy than most of the benchmark methods. Further analysis shows that the GP evolved programs have appropriate tree sizes and potentially high interpretability.}
}
