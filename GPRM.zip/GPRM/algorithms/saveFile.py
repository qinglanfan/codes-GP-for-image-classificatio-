import pickle

# import pygraphviz as pgv
from deap import gp


def saveResults(fileName, *args, **kwargs):
    f = open(fileName, 'w')
    for i in args:
        f.writelines(str(i)+'\n')
    f.close()
    return


# def saveLog (fileName, log):
#    f=open(fileName, 'wb')
#    pickle.dump(log, f)
#    f.close()
 #   return


# def plotTree(pathName,individual):
#    nodes, edges, labels = gp.graph(individual)
#    g = pgv.AGraph()
#    g.add_nodes_from(nodes)
#    g.add_edges_from(edges)
#    g.layout(prog="dot")

#    for i in nodes:
#        n = g.get_node(i)
#        n.attr["label"] = labels[i]
#    g.draw(pathName)
#    return


def bestInd(toolbox, population, number):
    bestInd = []
    best = toolbox.selectElitism(population, k=number)
    for i in best:
        bestInd.append(i)
    return bestInd
        

def saveAllResults(randomSeeds, dataSetName, best_ind_va, hof, trainTime, testTime, testResults, classifier):
#   treePath = str(randomSeeds)+'Treeon'+dataSetName+'.pdf'
#    plotTree(pathName=treePath, individual=hof2[0])
#    fileName1= str(randomSeeds)+'Resultson' + dataSetName+ '.txt'
#    saveLog(fileName1, log)
    fileName = str(randomSeeds)+'FinalResult' + dataSetName + '.txt'
    saveResults(fileName, 'randomSeed', randomSeeds, 'trainTime', trainTime,
                         'trainResults', hof[0].fitness,
                         'testTime', testTime, 'testResults', testResults, 'bestInd in training',
                         hof[0],  'Best individual',
                        *best_ind_va[:], 'classifier: 1-lsvm, 2-rf, 3-lr, 4-erf', classifier,
                'the size of the best individual', len(best_ind_va[0])-1
                        )

    return
